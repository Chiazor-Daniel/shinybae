import React from "react";
import { ShoppingBag, Search, User, Menu, Heart } from "lucide-react";

interface HeaderProps {
  cartCount: number;
  onCartClick: () => void;
  onPageChange: (page: string) => void;
  currentPage: string;
}

const Header: React.FC<HeaderProps> = ({
  cartCount,
  onCartClick,
  onPageChange,
  currentPage,
}) => {
  const navItems = [
    { id: "home", label: "Home" },
    { id: "shop", label: "Shop" },
    { id: "blog", label: "Blog" },
    { id: "about", label: "About" },
  ];

  return (
    <header className="backdrop-blur-glass shadow-pink sticky top-0 z-40 border-b border-white/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div
            className="flex-shrink-0 cursor-pointer group"
            onClick={() => onPageChange("home")}
          >
            <h1 className="text-3xl font-dancing font-bold text-gradient group-hover:scale-105 transition-transform duration-300">
              ShinyBae
            </h1>
          </div>

          {/* Navigation - Desktop */}
          <nav className="hidden md:flex space-x-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onPageChange(item.id)}
                className={`text-sm font-medium font-inter transition-all duration-300 hover:scale-105 ${
                  currentPage === item.id
                    ? "text-pink-500 border-b-2 border-pink-500"
                    : "text-gray-700 hover:text-pink-500"
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Right side icons */}
          <div className="flex items-center space-x-4">
            <button className="p-2 text-gray-600 hover:text-pink-500 transition-all duration-300 hover:scale-110 rounded-full hover:bg-pink-50">
              <Search size={20} />
            </button>
            <button className="p-2 text-gray-600 hover:text-pink-500 transition-all duration-300 hover:scale-110 rounded-full hover:bg-pink-50">
              <Heart size={20} />
            </button>
            <button className="p-2 text-gray-600 hover:text-pink-500 transition-all duration-300 hover:scale-110 rounded-full hover:bg-pink-50">
              <User size={20} />
            </button>
            <button
              onClick={onCartClick}
              className="relative p-2 text-gray-600 hover:text-pink-500 transition-all duration-300 hover:scale-110 rounded-full hover:bg-pink-50 group"
            >
              <ShoppingBag size={20} />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-gradient-to-r from-pink-400 to-pink-400 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center animate-pulse group-hover:animate-bounce">
                  {cartCount}
                </span>
              )}
            </button>
            <button className="md:hidden p-2 text-gray-600 hover:text-pink-500 transition-all duration-300 hover:scale-110 rounded-full hover:bg-pink-50">
              <Menu size={20} />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
