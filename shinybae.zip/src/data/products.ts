import { Product, BlogPost } from "../types";
import shinyImage from "../../assets/shiny.jpeg";
export const products: Product[] = [
  {
    id: "1",
    name: "ShinyBae",
    price: 24.99,
    originalPrice: 29.99,
    image: shinyImage,
    images: [shinyImage],
    description:
      "ShinyBae is our signature glossy formula that delivers high-shine and long-lasting moisture. Perfect for everyday wear with a subtle blush tint.",
    ingredients: [
      "Hyaluronic Acid",
      "Vitamin E",
      "Jojoba Oil",
      "Coconut Oil",
      "Natural Flavoring",
    ],
    shades: [
      {
        id: "s1",
        name: "Rose Quartz",
        color: "#F8BBD9",
        image:
          "https://images.pexels.com/photos/3993449/pexels-photo-3993449.jpeg?auto=compress&cs=tinysrgb&w=200",
      },
      {
        id: "s2",
        name: "Coral Dreams",
        color: "#FF7F7F",
        image:
          "https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg?auto=compress&cs=tinysrgb&w=200",
      },
      {
        id: "s3",
        name: "Berry Blush",
        color: "#C47B8C",
        image:
          "https://images.pexels.com/photos/3785147/pexels-photo-3785147.jpeg?auto=compress&cs=tinysrgb&w=200",
      },
    ],
    category: "gloss",
    isBestSeller: true,
    isNew: false,
    stock: 45,
  },
  {
    id: "2",
    name: "Shimmer Goddess",
    price: 26.99,
    image:
      "https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg?auto=compress&cs=tinysrgb&w=800",
    images: [
      "https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg?auto=compress&cs=tinysrgb&w=800",
      "https://images.pexels.com/photos/3785147/pexels-photo-3785147.jpeg?auto=compress&cs=tinysrgb&w=800",
    ],
    description:
      "Ultra-glossy formula with fine shimmer particles that catch the light beautifully. Makes lips appear fuller and more defined.",
    ingredients: [
      "Mica",
      "Hyaluronic Acid",
      "Vitamin E",
      "Sweet Almond Oil",
      "Vanilla Extract",
    ],
    shades: [
      {
        id: "s4",
        name: "Golden Hour",
        color: "#E9A178",
        image:
          "https://images.pexels.com/photos/4041392/pexels-photo-4041392.jpeg?auto=compress&cs=tinysrgb&w=200",
      },
      {
        id: "s5",
        name: "Champagne Pop",
        color: "#F7E7CE",
        image:
          "https://images.pexels.com/photos/3785147/pexels-photo-3785147.jpeg?auto=compress&cs=tinysrgb&w=200",
      },
    ],
    category: "shimmer",
    isBestSeller: true,
    isNew: true,
    stock: 32,
  },
  {
    id: "3",
    name: "Velvet Touch",
    price: 22.99,
    image:
      "https://images.pexels.com/photos/3785147/pexels-photo-3785147.jpeg?auto=compress&cs=tinysrgb&w=800",
    images: [
      "https://images.pexels.com/photos/3785147/pexels-photo-3785147.jpeg?auto=compress&cs=tinysrgb&w=800",
      "https://images.pexels.com/photos/3993449/pexels-photo-3993449.jpeg?auto=compress&cs=tinysrgb&w=800",
    ],
    description:
      "Luxurious matte-finish gloss that provides comfort and hydration without the sticky feel. Perfect for sophisticated looks.",
    ingredients: [
      "Shea Butter",
      "Coconut Oil",
      "Vitamin E",
      "Natural Waxes",
      "Peppermint Oil",
    ],
    shades: [
      {
        id: "s6",
        name: "Nude Luxe",
        color: "#D4A6A6",
        image:
          "https://images.pexels.com/photos/3785147/pexels-photo-3785147.jpeg?auto=compress&cs=tinysrgb&w=200",
      },
      {
        id: "s7",
        name: "Mauve Magic",
        color: "#A67B8C",
        image:
          "https://images.pexels.com/photos/3993449/pexels-photo-3993449.jpeg?auto=compress&cs=tinysrgb&w=200",
      },
    ],
    category: "matte",
    isBestSeller: false,
    isNew: true,
    stock: 28,
  },
];

export const blogPosts: BlogPost[] = [
  {
    id: "1",
    title: "5 Tips for Long-Lasting Lip Gloss",
    excerpt:
      "Discover the secrets to making your lip gloss last all day with these expert tips from our beauty team.",
    image:
      "https://images.pexels.com/photos/3373736/pexels-photo-3373736.jpeg?auto=compress&cs=tinysrgb&w=600",
    date: "2024-01-15",
    readTime: "3 min read",
    category: "Tips",
  },
  {
    id: "2",
    title: "The Art of Lip Care",
    excerpt:
      "Learn about the importance of lip care and how our moisturizing formulas keep your lips healthy and beautiful.",
    image:
      "https://images.pexels.com/photos/3762879/pexels-photo-3762879.jpeg?auto=compress&cs=tinysrgb&w=600",
    date: "2024-01-10",
    readTime: "5 min read",
    category: "Care",
  },
  {
    id: "3",
    title: "Behind the Scenes: Creating ShinyBae",
    excerpt:
      "Take a peek behind the curtain and discover how we handcraft each lip gloss with love and attention to detail.",
    image:
      "https://images.pexels.com/photos/3886244/pexels-photo-3886244.jpeg?auto=compress&cs=tinysrgb&w=600",
    date: "2024-01-05",
    readTime: "4 min read",
    category: "Brand",
  },
];
